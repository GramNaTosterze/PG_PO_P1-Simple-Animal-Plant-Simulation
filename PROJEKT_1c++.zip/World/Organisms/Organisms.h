#pragma once

#include "Animals/Antelope.h"
#include "Animals/CyberSheep.h"
#include "Animals/Fox.h"
#include "Animals/Human.h"
#include "Animals/Sheep.h"
#include "Animals/Turtle.h"
#include "Animals/Wolf.h"

#include "Plants/AtropaBelladonna.h"
#include "Plants/Dandelion.h"
#include "Plants/Grass.h"
#include "Plants/Guarana.h"
#include "Plants/HeracleumSosnowskyi.h"

